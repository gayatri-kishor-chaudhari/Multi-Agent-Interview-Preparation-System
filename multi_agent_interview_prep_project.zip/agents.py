import re
from collections import Counter

from PyPDF2 import PdfReader


ROLE_SKILLS = {
    "Software Engineer Fresher": ["python", "java", "sql", "dbms", "dsa", "oops", "git", "github", "html", "css"],
    "Python Developer": ["python", "flask", "django", "sql", "api", "git", "github", "oops", "debugging"],
    "Java Developer": ["java", "oops", "collection", "spring", "sql", "jdbc", "exception", "git"],
    "Data Analyst": ["python", "sql", "excel", "pandas", "numpy", "dashboard", "statistics", "visualization"],
    "Web Developer": ["html", "css", "javascript", "responsive", "api", "git", "database", "bootstrap"],
    "QA Automation": ["testing", "selenium", "python", "java", "test cases", "bug", "automation", "api"],
}


JOB_LINKS = {
    "Python Developer": [
        ("LinkedIn Python Developer Pune", "https://www.linkedin.com/jobs/search/?keywords=Python%20Developer%20Fresher&location=Pune"),
        ("Naukri Python Fresher Pune", "https://www.naukri.com/python-developer-fresher-jobs-in-pune"),
        ("Internshala Python Jobs Pune", "https://internshala.com/jobs/python-developer-jobs-in-pune/"),
        ("Foundit Python Fresher Pune", "https://www.foundit.in/search/python-fresher-jobs-in-pune"),
    ],
    "Java Developer": [
        ("LinkedIn Java Developer Pune", "https://www.linkedin.com/jobs/search/?keywords=Java%20Developer%20Fresher&location=Pune"),
        ("Naukri Java Fresher Pune", "https://www.naukri.com/java-developer-fresher-jobs-in-pune"),
        ("Internshala Java Jobs", "https://internshala.com/jobs/java-jobs/"),
        ("Foundit Java Fresher Pune", "https://www.foundit.in/search/java-fresher-jobs-in-pune"),
    ],
    "Software Engineer Fresher": [
        ("LinkedIn Software Engineer Fresher Pune", "https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%20Fresher&location=Pune"),
        ("Naukri Software Fresher Pune", "https://www.naukri.com/software-engineer-fresher-jobs-in-pune"),
        ("Foundit Fresher Jobs Pune", "https://www.foundit.in/search/fresher-jobs-in-pune"),
        ("TCS Careers India", "https://www.tcs.com/careers/india"),
    ],
    "Data Analyst": [
        ("LinkedIn Data Analyst Fresher Pune", "https://www.linkedin.com/jobs/search/?keywords=Data%20Analyst%20Fresher&location=Pune"),
        ("Naukri Data Analyst Fresher Pune", "https://www.naukri.com/data-analyst-fresher-jobs-in-pune"),
        ("Internshala Data Analyst Jobs", "https://internshala.com/jobs/data-analyst-jobs/"),
        ("Foundit Data Analyst Fresher Pune", "https://www.foundit.in/search/data-analyst-fresher-jobs-in-pune"),
    ],
    "Web Developer": [
        ("LinkedIn Web Developer Fresher Pune", "https://www.linkedin.com/jobs/search/?keywords=Web%20Developer%20Fresher&location=Pune"),
        ("Naukri Web Developer Fresher Pune", "https://www.naukri.com/web-developer-fresher-jobs-in-pune"),
        ("Internshala Web Development Jobs", "https://internshala.com/jobs/web-development-jobs/"),
        ("Foundit Web Developer Fresher Pune", "https://www.foundit.in/search/web-developer-fresher-jobs-in-pune"),
    ],
    "QA Automation": [
        ("LinkedIn QA Automation Fresher Pune", "https://www.linkedin.com/jobs/search/?keywords=QA%20Automation%20Fresher&location=Pune"),
        ("Naukri QA Fresher Pune", "https://www.naukri.com/qa-fresher-jobs-in-pune"),
        ("Internshala Testing Jobs", "https://internshala.com/jobs/software-testing-jobs/"),
        ("Foundit QA Fresher Pune", "https://www.foundit.in/search/qa-fresher-jobs-in-pune"),
    ],
}


QUIZ_BANK = {
    "DSA Agent": {
        "description": "Practice data structures and algorithms MCQs for fresher interviews.",
        "questions": [
            {
                "question": "Which data structure follows LIFO order?",
                "options": ["Queue", "Stack", "Array", "Tree"],
                "answer": "Stack",
                "explanation": "Stack follows Last In First Out order.",
            },
            {
                "question": "What is the average time complexity of binary search?",
                "options": ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
                "answer": "O(log n)",
                "explanation": "Binary search halves the search space each step.",
            },
            {
                "question": "Which structure is best for BFS traversal?",
                "options": ["Stack", "Queue", "Heap", "HashMap"],
                "answer": "Queue",
                "explanation": "BFS processes nodes level by level using a queue.",
            },
            {
                "question": "Which sorting algorithm has worst-case O(n^2)?",
                "options": ["Merge Sort", "Heap Sort", "Quick Sort", "Counting Sort"],
                "answer": "Quick Sort",
                "explanation": "Quick sort can become O(n^2) with poor pivot choices.",
            },
        ],
    },
    "SQL Agent": {
        "description": "Practice SQL, DBMS, joins, keys and query basics.",
        "questions": [
            {
                "question": "Which SQL clause filters grouped records?",
                "options": ["WHERE", "HAVING", "ORDER BY", "LIMIT"],
                "answer": "HAVING",
                "explanation": "HAVING filters groups after GROUP BY.",
            },
            {
                "question": "Which key uniquely identifies each row in a table?",
                "options": ["Foreign Key", "Candidate Key", "Primary Key", "Composite Key"],
                "answer": "Primary Key",
                "explanation": "Primary key uniquely identifies table records.",
            },
            {
                "question": "Which join returns all rows from the left table?",
                "options": ["INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "CROSS JOIN"],
                "answer": "LEFT JOIN",
                "explanation": "LEFT JOIN returns all left table rows and matching right rows.",
            },
            {
                "question": "Which command removes all rows but keeps table structure?",
                "options": ["DROP", "DELETE", "TRUNCATE", "ALTER"],
                "answer": "TRUNCATE",
                "explanation": "TRUNCATE removes rows and keeps the table structure.",
            },
        ],
    },
    "Python Agent": {
        "description": "Practice Python fundamentals, OOP and Flask-ready concepts.",
        "questions": [
            {
                "question": "Which Python data type stores key-value pairs?",
                "options": ["List", "Tuple", "Dictionary", "Set"],
                "answer": "Dictionary",
                "explanation": "Dictionary stores data as key-value pairs.",
            },
            {
                "question": "What does Flask mainly help build?",
                "options": ["Mobile apps", "Web applications", "Operating systems", "Compilers"],
                "answer": "Web applications",
                "explanation": "Flask is a lightweight Python web framework.",
            },
            {
                "question": "Which keyword defines a function in Python?",
                "options": ["func", "define", "def", "function"],
                "answer": "def",
                "explanation": "Python uses def to define functions.",
            },
            {
                "question": "Which concept hides internal implementation details?",
                "options": ["Encapsulation", "Compilation", "Iteration", "Indexing"],
                "answer": "Encapsulation",
                "explanation": "Encapsulation is an important OOP principle.",
            },
        ],
    },
    "Java Agent": {
        "description": "Practice Java MCQs for students targeting Java developer roles.",
        "questions": [
            {
                "question": "Which method is the entry point of a Java program?",
                "options": ["start()", "run()", "main()", "init()"],
                "answer": "main()",
                "explanation": "Java execution starts from the main method.",
            },
            {
                "question": "Which keyword is used to inherit a class in Java?",
                "options": ["implements", "extends", "inherits", "super"],
                "answer": "extends",
                "explanation": "extends is used for class inheritance.",
            },
            {
                "question": "Which collection does not allow duplicate elements?",
                "options": ["List", "Set", "Queue", "ArrayList"],
                "answer": "Set",
                "explanation": "Set stores unique elements.",
            },
            {
                "question": "Which block always executes after try-catch?",
                "options": ["final", "finally", "throw", "throws"],
                "answer": "finally",
                "explanation": "finally runs whether an exception occurs or not.",
            },
        ],
    },
    "C/C++ Agent": {
        "description": "Practice C and C++ fundamentals for campus interviews.",
        "questions": [
            {
                "question": "Which operator is used to access a value through a pointer in C?",
                "options": ["&", "*", "->", "."],
                "answer": "*",
                "explanation": "The * operator dereferences a pointer.",
            },
            {
                "question": "Which C++ feature allows same function name with different parameters?",
                "options": ["Inheritance", "Encapsulation", "Function Overloading", "Abstraction"],
                "answer": "Function Overloading",
                "explanation": "Function overloading allows multiple signatures.",
            },
            {
                "question": "Which memory area is used by malloc?",
                "options": ["Stack", "Heap", "Register", "Code segment"],
                "answer": "Heap",
                "explanation": "Dynamic allocation uses heap memory.",
            },
            {
                "question": "Which keyword creates an object dynamically in C++?",
                "options": ["malloc", "alloc", "new", "create"],
                "answer": "new",
                "explanation": "new dynamically allocates C++ objects.",
            },
        ],
    },
    "Web Agent": {
        "description": "Practice HTML, CSS and basic web development questions.",
        "questions": [
            {
                "question": "Which HTML tag is used for the largest heading?",
                "options": ["h1", "head", "heading", "h6"],
                "answer": "h1",
                "explanation": "h1 is the highest-level heading.",
            },
            {
                "question": "Which CSS property changes text color?",
                "options": ["font", "text-style", "color", "background"],
                "answer": "color",
                "explanation": "The color property controls text color.",
            },
            {
                "question": "Which layout system is one-dimensional?",
                "options": ["Grid", "Flexbox", "Table", "Block"],
                "answer": "Flexbox",
                "explanation": "Flexbox is mainly one-dimensional.",
            },
            {
                "question": "Which status code means page not found?",
                "options": ["200", "301", "404", "500"],
                "answer": "404",
                "explanation": "404 means the resource was not found.",
            },
        ],
    },
    "Aptitude Agent": {
        "description": "Practice aptitude questions commonly asked in fresher drives.",
        "questions": [
            {
                "question": "If 20% of a number is 50, what is the number?",
                "options": ["100", "150", "200", "250"],
                "answer": "250",
                "explanation": "50 is 20%, so number is 50 / 0.20 = 250.",
            },
            {
                "question": "A train covers 120 km in 2 hours. What is its speed?",
                "options": ["40 km/h", "50 km/h", "60 km/h", "80 km/h"],
                "answer": "60 km/h",
                "explanation": "Speed = distance / time = 120 / 2.",
            },
            {
                "question": "Find the next number: 2, 4, 8, 16, ?",
                "options": ["18", "24", "32", "64"],
                "answer": "32",
                "explanation": "Each term is multiplied by 2.",
            },
            {
                "question": "What is the average of 10, 20, 30, 40?",
                "options": ["20", "25", "30", "35"],
                "answer": "25",
                "explanation": "Average is 100 / 4 = 25.",
            },
        ],
    },
}


HR_QUESTIONS = [
    "Tell me about yourself.",
    "Why should we hire you?",
    "Explain one project from your resume.",
    "What are your strengths and weaknesses?",
]


def extract_pdf_text(path):
    reader = PdfReader(str(path))
    text = []
    for page in reader.pages:
        text.append(page.extract_text() or "")
    return "\n".join(text)


def normalize(text):
    return re.sub(r"\s+", " ", text.lower())


def score_quiz(topic, answers):
    questions = QUIZ_BANK[topic]["questions"]
    correct = 0
    review = []

    for index, question in enumerate(questions):
        selected = answers.get(str(index), "")
        is_correct = selected == question["answer"]
        if is_correct:
            correct += 1
        review.append(
            {
                "question": question["question"],
                "selected": selected or "Not answered",
                "answer": question["answer"],
                "is_correct": is_correct,
                "explanation": question["explanation"],
            }
        )

    score = int((correct / len(questions)) * 100)
    if score >= 80:
        feedback = "Excellent. You are ready for this topic."
    elif score >= 50:
        feedback = "Good start. Revise wrong answers and practice more."
    else:
        feedback = "Needs practice. Focus on basics and retry this agent."

    return {"score": score, "correct": correct, "total": len(questions), "feedback": feedback, "review": review}


def analyze_resume(text, role_profile):
    clean_text = normalize(text)
    required = ROLE_SKILLS.get(role_profile, ROLE_SKILLS["Software Engineer Fresher"])
    matched = [skill for skill in required if skill in clean_text]
    missing = [skill for skill in required if skill not in clean_text]

    section_checks = {
        "Contact": "email" in clean_text or "phone" in clean_text or "linkedin" in clean_text,
        "GitHub": "github" in clean_text,
        "Projects": "project" in clean_text or "projects" in clean_text,
        "Education": "education" in clean_text or "bachelor" in clean_text or "computer science" in clean_text,
        "Experience": "internship" in clean_text or "experience" in clean_text or "training" in clean_text,
    }

    keyword_score = int((len(matched) / len(required)) * 55)
    section_score = int((sum(section_checks.values()) / len(section_checks)) * 30)
    impact_score = 15 if re.search(r"\d+%|\d+\+|\d+\s*(users|projects|apis|modules|cgpa)", clean_text) else 5
    score = min(keyword_score + section_score + impact_score, 100)

    if score >= 75:
        summary = "Resume is strong for shortlisting."
    elif score >= 55:
        summary = "Resume is decent but needs more role-specific keywords and project impact."
    else:
        summary = "Resume needs improvement before applying aggressively."

    suggestions = []
    if missing:
        suggestions.append("Add missing role skills naturally: " + ", ".join(missing[:8]))
    if not section_checks["GitHub"]:
        suggestions.append("Add GitHub link with pinned projects.")
    if impact_score < 15:
        suggestions.append("Add measurable impact such as accuracy, users, modules, APIs, or project count.")

    return {
        "score": score,
        "summary": summary,
        "matched": matched,
        "missing": missing,
        "section_checks": section_checks,
        "suggestions": suggestions,
    }


def analyze_hr_answers(answers):
    total = 0
    improvements = []
    strengths = []

    for index, answer in enumerate(answers):
        clean = normalize(answer)
        words = re.findall(r"[a-zA-Z]+", clean)
        points = 0

        if len(words) >= 35:
            points += 10
        else:
            improvements.append(f"Answer {index + 1}: Add more detail and structure.")

        if any(word in clean for word in ["project", "python", "sql", "team", "learn", "problem", "developed", "built"]):
            points += 8
        else:
            improvements.append(f"Answer {index + 1}: Include skills, project examples, or learning attitude.")

        if any(word in clean for word in ["because", "for example", "result", "improved", "challenge"]):
            points += 7
        else:
            improvements.append(f"Answer {index + 1}: Add one example or result.")

        total += points

    score = int((total / (len(answers) * 25)) * 100)

    if score >= 75:
        feedback = "HR answers are confident and interview-ready."
        strengths.append("Good answer depth and role connection.")
    elif score >= 50:
        feedback = "HR answers are understandable but need stronger examples."
    else:
        feedback = "HR answers need more structure, examples and confidence."

    return {"score": score, "feedback": feedback, "strengths": strengths, "improvements": improvements[:8]}


def get_role_recommendations(role):
    links = JOB_LINKS.get(role, JOB_LINKS["Software Engineer Fresher"])
    post = (
        f"I am actively looking for {role} opportunities. "
        "I have hands-on skills in Python, SQL, DBMS, DSA, Git/GitHub, HTML/CSS, "
        "and practical project development. I would appreciate referrals, guidance, "
        "or fresher openings matching my profile."
    )
    message = (
        f"Hi, I am looking for {role} fresher opportunities. "
        "I have worked on practical projects and I am ready for interview assessments. "
        "Could you please guide me or refer me if there is a suitable opening?"
    )
    return {"links": links, "linkedin_post": post, "hr_message": message}


def build_overall_feedback(rows):
    if not rows:
        return {"average": 0, "message": "Start practice with any agent to see overall progress."}

    scores = [row["score"] for row in rows]
    average = int(sum(scores) / len(scores))
    if average >= 80:
        message = "Excellent overall readiness. Start applying daily and revise weak areas."
    elif average >= 60:
        message = "Good progress. Practice low-score agents and improve resume keywords."
    else:
        message = "Focus on fundamentals first. Practice MCQs, HR answers, and resume agent daily."

    return {"average": average, "message": message}
