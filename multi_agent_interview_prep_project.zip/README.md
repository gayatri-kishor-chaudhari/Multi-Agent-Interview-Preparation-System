# Multi-Agent Interview Preparation System

A Python Flask project for fresher candidates and students. It provides a multi-agent practice dashboard for resume screening, MCQ tests, HR interview practice, score tracking and job-profile application links.

## Project Idea

Many students prepare from different websites, notes and PDFs. This project brings important fresher interview preparation into one dashboard using agent-style modules:

- Resume Agent
- DSA Agent
- SQL Agent
- Python Agent
- Java Agent
- C/C++ Agent
- Web Agent
- Aptitude Agent
- HR Agent
- Career Links Agent
- Overall Score Agent

Java is included only as a practice topic. The project technology is Python, Flask, SQLite, PyPDF2, HTML and CSS.

## Features

- Dashboard for all practice agents
- Resume PDF upload and role-wise resume score
- DSA MCQ practice
- SQL and DBMS MCQ practice
- Python MCQ practice
- Java MCQ practice
- C/C++ MCQ practice
- HTML/CSS/Web MCQ practice
- Aptitude MCQ practice
- HR answer writing and scoring
- Result display with correct answers and explanations
- SQLite practice history
- Overall readiness score
- Role-wise job search links
- LinkedIn post generator
- HR/referral message generator

## Tech Stack

- Python
- Flask
- SQLite / SQL
- PyPDF2
- HTML
- CSS

## How To Run

Open the project folder in VS Code or PowerShell.

Install dependencies:

```bash
py -m pip install -r requirements.txt
```

Run the application:

```bash
py app.py
```

Open in browser:

```text
http://127.0.0.1:5000
```

If `py` does not work, use:

```bash
python -m pip install -r requirements.txt
python app.py
```

## Resume Line

Multi-Agent Interview Preparation System | Python, Flask, SQLite, PyPDF2, HTML, CSS

Built a multi-agent fresher interview preparation dashboard with Resume Agent, DSA Agent, SQL Agent, Python Agent, Java Agent, C/C++ Agent, Web Agent, Aptitude Agent and HR Agent. The system provides MCQ tests, resume scoring, HR answer evaluation, score history, job-profile links and LinkedIn/HR message templates.

## Interview Explanation

This project follows an agent-style architecture where each module is responsible for one student preparation task. The dashboard acts as the coordinator. The Resume Agent extracts text from PDF resumes and checks role-wise skill matching. MCQ agents evaluate technical topics and return explanations. The HR Agent checks answer depth, examples and confidence indicators. The Career Links Agent generates job search links and outreach content for different profiles.

## Future Enhancements

- Add admin panel to add new questions
- Add student login
- Add difficulty levels
- Add charts for progress tracking
- Add export result as PDF
- Add RAG-based answer explanation from uploaded notes
- Add voice-based mock interview
