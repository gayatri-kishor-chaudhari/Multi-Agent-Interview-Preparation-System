import os
import sqlite3
from datetime import datetime
from pathlib import Path

from flask import Flask, render_template, request
from werkzeug.utils import secure_filename

from agents import (
    HR_QUESTIONS,
    JOB_LINKS,
    QUIZ_BANK,
    analyze_hr_answers,
    analyze_resume,
    build_overall_feedback,
    extract_pdf_text,
    get_role_recommendations,
    score_quiz,
)


BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
DB_PATH = BASE_DIR / "practice_history.db"
ALLOWED_EXTENSIONS = {"pdf"}

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_DIR
app.config["MAX_CONTENT_LENGTH"] = 6 * 1024 * 1024


def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS practice_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_name TEXT NOT NULL,
                role_profile TEXT NOT NULL,
                practice_type TEXT NOT NULL,
                score INTEGER NOT NULL,
                feedback TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.commit()


def save_result(student_name, role_profile, practice_type, score, feedback):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            INSERT INTO practice_results
                (student_name, role_profile, practice_type, score, feedback, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                student_name,
                role_profile,
                practice_type,
                score,
                feedback,
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            ),
        )
        conn.commit()


def get_recent_results():
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        return conn.execute(
            """
            SELECT student_name, role_profile, practice_type, score, feedback, created_at
            FROM practice_results
            ORDER BY id DESC
            LIMIT 8
            """
        ).fetchall()


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/")
def dashboard():
    init_db()
    return render_template(
        "dashboard.html",
        quiz_bank=QUIZ_BANK,
        job_links=JOB_LINKS,
        recent_results=get_recent_results(),
    )


@app.route("/quiz/<topic>", methods=["GET", "POST"])
def quiz(topic):
    init_db()
    if topic not in QUIZ_BANK:
        return render_template("message.html", title="Topic not found", message="Please select a valid practice topic.")

    result = None
    questions = QUIZ_BANK[topic]["questions"]

    if request.method == "POST":
        student_name = request.form.get("student_name", "Student").strip() or "Student"
        role_profile = request.form.get("role_profile", "Software Engineer Fresher")
        answers = {str(index): request.form.get(f"q{index}", "") for index in range(len(questions))}
        result = score_quiz(topic, answers)
        save_result(student_name, role_profile, topic, result["score"], result["feedback"])

    return render_template(
        "quiz.html",
        topic=topic,
        topic_data=QUIZ_BANK[topic],
        result=result,
    )


@app.route("/resume-agent", methods=["GET", "POST"])
def resume_agent():
    init_db()
    result = None
    error = None

    if request.method == "POST":
        student_name = request.form.get("student_name", "Student").strip() or "Student"
        role_profile = request.form.get("role_profile", "Software Engineer Fresher")
        resume_file = request.files.get("resume")

        if not resume_file or resume_file.filename == "":
            error = "Please upload a PDF resume."
        elif not allowed_file(resume_file.filename):
            error = "Only PDF files are supported."
        else:
            os.makedirs(UPLOAD_DIR, exist_ok=True)
            filename = secure_filename(resume_file.filename)
            path = UPLOAD_DIR / filename
            resume_file.save(path)

            text = extract_pdf_text(path)
            if not text.strip():
                error = "Could not read this PDF. Please upload a text-based resume PDF."
            else:
                result = analyze_resume(text, role_profile)
                save_result(student_name, role_profile, "Resume Agent", result["score"], result["summary"])

    return render_template("resume_agent.html", result=result, error=error)


@app.route("/hr-agent", methods=["GET", "POST"])
def hr_agent():
    init_db()
    result = None

    if request.method == "POST":
        student_name = request.form.get("student_name", "Student").strip() or "Student"
        role_profile = request.form.get("role_profile", "Software Engineer Fresher")
        answers = [request.form.get(f"answer{index}", "") for index in range(len(HR_QUESTIONS))]
        result = analyze_hr_answers(answers)
        save_result(student_name, role_profile, "HR Agent", result["score"], result["feedback"])

    return render_template("hr_agent.html", questions=HR_QUESTIONS, result=result)


@app.route("/career-links", methods=["GET", "POST"])
def career_links():
    selected_role = "Python Developer"
    recommendations = get_role_recommendations(selected_role)

    if request.method == "POST":
        selected_role = request.form.get("role_profile", selected_role)
        recommendations = get_role_recommendations(selected_role)

    return render_template(
        "career_links.html",
        roles=list(JOB_LINKS.keys()),
        selected_role=selected_role,
        recommendations=recommendations,
    )


@app.route("/overall")
def overall():
    init_db()
    rows = get_recent_results()
    feedback = build_overall_feedback(rows)
    return render_template("overall.html", recent_results=rows, feedback=feedback)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
